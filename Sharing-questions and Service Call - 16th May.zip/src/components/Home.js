import React,{Component} from 'react';

export default class Home extends Component{


    constructor(props){
        super();


    }

    add_customer=()=>
    {
        var name = this.refs.uname.value;
        localStorage.setItem("uname",name);
        console.log(localStorage.getItem('uname'));
    }
    render(){

        return(

                <div>
                        <h1>  Home !!!! Component </h1>
                        <p>
                             <input placeholder="User Name" className="form-control" type="text" ref="uname" />
                        </p>
                        <p>
                           <input type="button" className="btn btn-primary" value="Add User" onClick={this.add_customer} />
                        </p>
                        


                </div>


        );

    }



}

