
import React from 'react';

import Header from './components/Header';
import Footer from './components/Footer';

class App extends React.Component{


  constructor(){

    super();
    this.state ={

      data:'abcd'
    }
  }

  frm_click=()=>{

        this.setState({data:'new data ..is changed'});

  }
  render(){

    var a =11;
    var b =44;
    var c  = a+b;

    return(
      <div>

      <Header/>
        <p>
          Name : <input type="text" />

          <input type="button" onClick={this.frm_click} value="Click Me" />


        </p>

      <p>
          Expression (Interpolation) { 2+ 2}
        </p>

      <p>
            {c }
        </p>

        <p>
          {this.state.data}
          </p>


      <Footer/>
      </div>


    );
  }

}

export default App;
