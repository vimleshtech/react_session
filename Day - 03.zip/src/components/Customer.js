import React,{Component} from 'react';

export default class Customer extends Component{


    constructor(){
        super();

    }

    render(){

        return(

                <div>
                        <h1>  Customer !!!! Component </h1>
                </div>


        );

    }



}

