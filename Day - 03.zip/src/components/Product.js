import React,{Component} from 'react';

export default class Product extends Component{
    constructor(){
        super();
        console.log('in constructor -product');
    }

    render(){

        return(

                <div>
                        <h1>  Product !!!! Component </h1>
                </div>


        );

    }



}

