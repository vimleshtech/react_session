import React from 'react';
import logo from './logo.svg';
import './App.scss';
import './styles.scss';

import './impstyle.scss';



function App() {
  return (
    <div className="App">

      <h1>
          Test Responsive Header
      </h1>

      <h2>
          Test Responsive Sub Header
      </h2>

      <div>
        
        <span className="span">
            hi     
        </span>


        <span className="span">
              hello 
        </span>


        <span className="span">
              test 
        </span>

          
      </div>

    </div>
  );
}

export default App;
